package etopupapp;



	public class Dealerapptestdata {
		
		 // ================= DEVICE CONFIG =================
	    public static final String PLATFORM_NAME = "Android";
	    public static final String PLATFORM_VERSION = "14";
	    public static final String DEVICE_NAME = "emulator-5554";
	    public static final String AUTOMATION_NAME = "UiAutomator2";
	    // ================= APP CONFIG =================
	    public static final String APP_PACKAGE = "app.tayana.etopup";
	    public static final String APP_ACTIVITY = "app.tayana.etopup.MainActivity";

	    // ================= LOGIN TEST DATA =================
	    public static final String LOCAL_NUMBER = "2565896";
	    public static final String COUNTRY_CODE = "248";
	    public static final String PIN = "123456";

	    // ================= SERVER CONFIG =================
	    public static final String APPIUM_URL = "http://127.0.0.1:4723";
	    
	 // ================= PACKPURCHASE CONFIG =================
	    
	    public static final String MOBILENUMBER="25999999";
	    public static final String DEALERPIN="1111";
	    public static final String BROADBANDPRENUMBER="30256789";
	    public static final String BROADBANDPOSNUMBER="TESTING123";
	    public static final String INVALIDMNUMBER="2719283";
	    
	    
	    
	    
	}


